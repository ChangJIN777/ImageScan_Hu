bit 3:SRS2
bit 4:SRS1
bit 5:SRS1's +Y
bit 7:SRS1's +X
bit 9: SRS2's +X.